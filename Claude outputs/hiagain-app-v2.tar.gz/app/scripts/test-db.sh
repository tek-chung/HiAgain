#!/usr/bin/env bash
# Applies the migrations to a throwaway local Postgres database (with a stand-in auth schema)
# and runs the access-control tests, including a concurrent-import check.
# Requires psql access to a local Postgres 15+ as a superuser: set PGHOST/PGUSER etc. as needed.
set -euo pipefail
cd "$(dirname "$0")/.."
DB="hiagain_test_$$"
cleanup() { dropdb --if-exists "$DB" >/dev/null 2>&1 || true; }
trap cleanup EXIT

createdb "$DB"
PSQL=(psql -X -q -v ON_ERROR_STOP=1 -d "$DB")
"${PSQL[@]}" -f supabase/tests/auth_stub.sql
for f in supabase/migrations/*.sql; do "${PSQL[@]}" -f "$f"; done
# rls_test.sql first (creates the shared fixtures), then the others in name order.
{ echo supabase/tests/rls_test.sql; ls supabase/tests/*_test.sql | grep -v "/rls_test.sql$" | sort; } | while read -r t; do "${PSQL[@]}" -f "$t"; done

# Concurrency: 8 parallel imports of the same batch for one account must leave exactly one row per person.
"${PSQL[@]}" <<'SQL'
insert into auth.users (id, raw_user_meta_data) values ('00000000-0000-4000-8000-0000000000d1', '{"name":"Concurrent Tester"}');
SQL
SUBJECTS=$("${PSQL[@]}" -At -c "select string_agg(format('{\"public_id\":\"%s\",\"saved_at\":\"2026-11-12T10:00:00Z\",\"note\":\"n\"}', public_id), ',') from public.profiles")
run_import() {
  "${PSQL[@]}" -At <<SQL >/dev/null
begin;
set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-4000-8000-0000000000d1"}', true);
select public.ensure_starter_profile();
select count(*) from public.import_guest_saves('[$SUBJECTS]'::jsonb);
commit;
SQL
}
pids=(); for i in $(seq 1 8); do run_import & pids+=($!); done
fail=0; for p in "${pids[@]}"; do wait "$p" || fail=1; done
[ "$fail" = 0 ] || { echo "concurrent import: a worker failed"; exit 1; }
COUNT=$("${PSQL[@]}" -At -c "select count(*) from public.saved_people where saver_id = '00000000-0000-4000-8000-0000000000d1'")
EXPECTED=$("${PSQL[@]}" -At -c "select count(*) from public.profiles where user_id <> '00000000-0000-4000-8000-0000000000d1'")
[ "$COUNT" = "$EXPECTED" ] || { echo "concurrent import: expected $EXPECTED rows, got $COUNT"; exit 1; }
PROFILES=$("${PSQL[@]}" -At -c "select count(*) from public.profiles where user_id = '00000000-0000-4000-8000-0000000000d1'")
[ "$PROFILES" = 1 ] || { echo "concurrent starter profile: got $PROFILES"; exit 1; }
echo "concurrency: 8 parallel imports -> $COUNT rows (expected $EXPECTED), 1 starter profile"
echo "test-db: PASS"
