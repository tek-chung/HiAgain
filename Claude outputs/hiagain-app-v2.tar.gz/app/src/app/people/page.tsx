import { createClient, getViewer } from "@/lib/supabase/server";
import type { SavedPerson } from "@/lib/core/types";
import { PeopleList } from "@/components/PeopleList";
import { ImportPanel } from "@/components/ImportPanel";

export const metadata = { title: "People" };
export const dynamic = "force-dynamic";

export default async function PeoplePage() {
  const viewer = await getViewer();
  let saves: (SavedPerson & { context?: string | null })[] | null = null;
  let loadError = false;
  if (viewer) {
    const supabase = (await createClient())!;
    const { data, error } = await supabase.rpc("my_saved_people");
    if (error) loadError = true;
    saves = ((data as Array<Record<string, string | null>> | null) ?? []).map((r) => ({
      publicId: r.public_id!, displayName: r.display_name ?? "", headline: r.headline, avatarUrl: r.avatar_url,
      linkedinUrl: r.linkedin_url, savedAt: r.saved_at!, note: r.note ?? "", noteUpdatedAt: r.note_updated_at,
      context: r.context_label,
    }));
  }
  return (
    <section>
      <h1>People</h1>
      {viewer && <ImportPanel accountName={viewer.displayName} />}
      {loadError && <p className="banner error" role="alert">Couldn&apos;t load your People. Refresh to try again.</p>}
      <PeopleList accountSaves={saves} />
    </section>
  );
}
