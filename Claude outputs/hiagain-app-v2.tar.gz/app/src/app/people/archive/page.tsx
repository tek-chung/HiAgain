import Link from "next/link";
import { createClient, getViewer } from "@/lib/supabase/server";
import { ArchiveList } from "@/components/ArchiveList";

export const metadata = { title: "Archive" };
export const dynamic = "force-dynamic";

export default async function ArchivePage() {
  const viewer = await getViewer();
  let archived = null;
  if (viewer) {
    const { data } = await (await createClient())!.rpc("my_archived_people");
    archived = ((data as Array<Record<string, any>> | null) ?? []).map((r) => ({
      publicId: r.public_id, displayName: r.display_name ?? "", headline: r.headline, avatarUrl: r.avatar_url,
    }));
  }
  return (
    <section>
      <Link className="btn plain small" href="/people" style={{ paddingLeft: 0 }}>‹ People</Link>
      <h1>Archive</h1>
      <p className="small muted">Private to you. Archiving doesn&apos;t block anyone or remove notes.</p>
      <ArchiveList accountArchived={archived} />
    </section>
  );
}
