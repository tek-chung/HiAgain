import Link from "next/link";
import { createClient, getViewer } from "@/lib/supabase/server";
import { isFixtureMode } from "@/lib/config";
import { ActivityList, type ActivityItem } from "@/components/ActivityList";

export const metadata = { title: "Activity" };
export const dynamic = "force-dynamic";

export default async function ActivityPage() {
  const viewer = await getViewer();
  if (!viewer) {
    return (
      <section className="stack">
        <h1>Activity</h1>
        <p className="muted">Sign in to see answers, requests and interest you&apos;ve sent and received.</p>
        {!isFixtureMode && <Link className="btn primary" href="/sign-in?next=/activity">Sign in</Link>}
      </section>
    );
  }
  const supabase = (await createClient())!;
  const { data, error } = await supabase.rpc("my_activity");
  const items: ActivityItem[] = ((data as Array<Record<string, any>> | null) ?? []).map((r) => ({
    id: r.id, direction: r.direction, kind: r.kind, promptSnapshot: r.prompt_snapshot, body: r.body ?? "",
    sentAt: r.sent_at, editedAt: r.edited_at, version: Number(r.version), unread: Boolean(r.unread),
    other: { publicId: r.other_public_id, displayName: r.other_display_name ?? "", avatarUrl: r.other_avatar_url },
  }));
  return (
    <section>
      <h1>Activity</h1>
      {error && <p className="banner error" role="alert">Couldn&apos;t load Activity. Refresh to try again.</p>}
      <ActivityList items={items} />
    </section>
  );
}
